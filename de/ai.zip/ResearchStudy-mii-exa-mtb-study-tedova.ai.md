# TEDOVA - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **TEDOVA**

## Beispiel ResearchStudy: TEDOVA

-------

**German**

-------

Profile: [MII PR MTB Studie](StructureDefinition-mii-pr-mtb-studie.md) version: 2027.0.0-ballot.1

**identifier**: [MII_NS_MTB_NCT](NamingSystem-mii-ns-mtb-nct.md)/04713514

**status**: Active



## Resource Content

```json
{
  "resourceType" : "ResearchStudy",
  "id" : "mii-exa-mtb-study-tedova",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studie|2027.0.0-ballot.1"]
  },
  "identifier" : [{
    "system" : "https://www.medizininformatik-initiative.de/fhir/modul-mtb/sid/nct",
    "value" : "04713514"
  }],
  "status" : "active"
}

```
