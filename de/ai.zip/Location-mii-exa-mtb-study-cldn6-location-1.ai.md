# NCT04503278 L1 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **NCT04503278 L1**

## Beispiel Location: NCT04503278 L1

-------

**German**

-------

**name**: Charité - Universitätsmedizin Berlin - Campus Benjamin Franklin

**address**: Berlin 12200 Germany 

### Positions

| | | |
| :--- | :--- | :--- |
| - | **Longitude** | **Latitude** |
| * | 13.41053 | 52.52437 |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "mii-exa-mtb-study-cldn6-location-1",
  "name" : "Charité - Universitätsmedizin Berlin - Campus Benjamin Franklin",
  "address" : {
    "city" : "Berlin",
    "postalCode" : "12200",
    "country" : "Germany"
  },
  "position" : {
    "longitude" : 13.41053,
    "latitude" : 52.52437
  }
}

```
