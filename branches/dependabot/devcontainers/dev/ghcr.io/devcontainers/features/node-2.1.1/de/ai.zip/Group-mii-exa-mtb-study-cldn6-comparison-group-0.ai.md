# NCT04503278 Comparison Group: Part 1 - CLDN6 CAR-T - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **NCT04503278 Comparison Group: Part 1 - CLDN6 CAR-T**

## Beispiel Group: NCT04503278 Comparison Group: Part 1 - CLDN6 CAR-T

-------

**German**

-------

**type**: Person

**actual**: false

### Characteristics

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Code** | **Value[x]** | **Exclude** |
| * | Exposed to | [Biological: CLDN6 CAR-T](EvidenceVariable-mii-exa-mtb-study-cldn6-evidence-variable-0.md) | false |



## Resource Content

```json
{
  "resourceType" : "Group",
  "id" : "mii-exa-mtb-study-cldn6-comparison-group-0",
  "type" : "person",
  "actual" : false,
  "characteristic" : [{
    "code" : {
      "text" : "Exposed to"
    },
    "valueReference" : {
      "reference" : "EvidenceVariable/mii-exa-mtb-study-cldn6-evidence-variable-0",
      "display" : "Biological: CLDN6 CAR-T"
    },
    "exclude" : false
  }]
}

```
