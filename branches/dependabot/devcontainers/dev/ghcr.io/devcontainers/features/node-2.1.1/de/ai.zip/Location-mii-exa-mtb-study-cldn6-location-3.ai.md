# NCT04503278 L3 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **NCT04503278 L3**

## Beispiel Location: NCT04503278 L3

-------

**German**

-------

**name**: Universitätsklinikum Hamburg Eppendorf - II Medizinische Klinik und Poliklinik

**address**: Hamburg 20246 Germany 

### Positions

| | | |
| :--- | :--- | :--- |
| - | **Longitude** | **Latitude** |
| * | 10.01534 | 53.57532 |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "mii-exa-mtb-study-cldn6-location-3",
  "name" : "Universitätsklinikum Hamburg Eppendorf - II Medizinische Klinik und Poliklinik",
  "address" : {
    "city" : "Hamburg",
    "postalCode" : "20246",
    "country" : "Germany"
  },
  "position" : {
    "longitude" : 10.01534,
    "latitude" : 53.57532
  }
}

```
