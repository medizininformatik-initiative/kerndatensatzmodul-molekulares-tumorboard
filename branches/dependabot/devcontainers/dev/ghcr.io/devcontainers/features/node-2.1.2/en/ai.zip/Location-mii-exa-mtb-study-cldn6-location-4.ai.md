# NCT04503278 L4 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NCT04503278 L4**

## Example Location: NCT04503278 L4

-------

**English**

-------

**name**: Medizinische Hochschule Hannover - Klinik für Hämatologie, Hämostaseologie, Onkologie und Stammzelltransplantation

**address**: Hannover 30625 Germany 

### Positions

| | | |
| :--- | :--- | :--- |
| - | **Longitude** | **Latitude** |
| * | 9.73322 | 52.37052 |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "mii-exa-mtb-study-cldn6-location-4",
  "name" : "Medizinische Hochschule Hannover - Klinik für Hämatologie, Hämostaseologie, Onkologie und Stammzelltransplantation",
  "address" : {
    "city" : "Hannover",
    "postalCode" : "30625",
    "country" : "Germany"
  },
  "position" : {
    "longitude" : 9.73322,
    "latitude" : 52.37052
  }
}

```
