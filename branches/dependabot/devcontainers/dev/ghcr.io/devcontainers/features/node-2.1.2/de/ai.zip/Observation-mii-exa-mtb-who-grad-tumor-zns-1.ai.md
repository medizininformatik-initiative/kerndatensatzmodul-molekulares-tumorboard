# MII PR MTB WHO Grad Tumor ZNS - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII PR MTB WHO Grad Tumor ZNS**

## Beispiel Observation: MII PR MTB WHO Grad Tumor ZNS

-------

**German**

-------

Profile: [MII PR MTB WHO Grad Tumor ZNS](StructureDefinition-mii-pr-mtb-who-grad-tumor-zns.md) version: 2027.0.0-ballot.1

**status**: Final

**code**: WHO grade finding for central nervous system tumor

**subject**: [Maxim Muster (no stated gender), DoB Unknown](Patient-mii-exa-mtb-patient.md)

**effective**: 2023-03-01

**value**: World Health Organization grade III central nervous system tumor (finding)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-mtb-who-grad-tumor-zns-1",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-who-grad-tumor-zns|2027.0.0-ballot.1"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "396921005",
      "display" : "WHO grade finding for central nervous system tumor"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-mtb-patient"
  },
  "effectiveDateTime" : "2023-03-01",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "396924002",
      "display" : "World Health Organization grade III central nervous system tumor (finding)"
    }]
  }
}

```
