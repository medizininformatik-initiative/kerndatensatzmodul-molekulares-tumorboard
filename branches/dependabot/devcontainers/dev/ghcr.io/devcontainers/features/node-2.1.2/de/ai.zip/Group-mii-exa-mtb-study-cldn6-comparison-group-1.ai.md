# NCT04503278 Comparison Group: Part 2 Vaccine-modulated - CLDN6 uRNA-LPX/CLDN6 modRNA-LPX - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **NCT04503278 Comparison Group: Part 2 Vaccine-modulated - CLDN6 uRNA-LPX/CLDN6 modRNA-LPX**

## Beispiel Group: NCT04503278 Comparison Group: Part 2 Vaccine-modulated - CLDN6 uRNA-LPX/CLDN6 modRNA-LPX

-------

**German**

-------

**type**: Person

**actual**: false

### Characteristics

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Code** | **Value[x]** | **Exclude** |
| * | Exposed to | [Biological: CLDN6 uRNA-LPX/CLDN6 modRNA-LPX](EvidenceVariable-mii-exa-mtb-study-cldn6-evidence-variable-1.md) | false |



## Resource Content

```json
{
  "resourceType" : "Group",
  "id" : "mii-exa-mtb-study-cldn6-comparison-group-1",
  "type" : "person",
  "actual" : false,
  "characteristic" : [{
    "code" : {
      "text" : "Exposed to"
    },
    "valueReference" : {
      "reference" : "EvidenceVariable/mii-exa-mtb-study-cldn6-evidence-variable-1",
      "display" : "Biological: CLDN6 uRNA-LPX/CLDN6 modRNA-LPX"
    },
    "exclude" : false
  }]
}

```
