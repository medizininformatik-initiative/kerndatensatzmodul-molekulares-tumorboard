# Downloads - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

This page links the downloadable artifacts of the **Molecular Tumor Board** module.

#### Package file

The package file is an NPM-format FHIR package used by most FHIR tooling. It contains all value sets, profiles, extensions and the list of pages and URLs of this guide, as defined by this version. It **SHOULD** be the first choice whenever implementation artifacts are generated, because it carries all rules that make the profiles valid. Implementers still need to know the specification content and the applicable profiles to build a conformant implementation — see the FHIR documentation on [validating profiles and resources](http://hl7.org/fhir/R4/validation.html).

* [Package (compressed folder)](../package.tgz)

#### Downloadable copy of this guide

A downloadable copy of the rendered guide, for hosting locally:

* [Downloadable copy (compressed folder)](../full-ig.zip)

#### Examples

All examples of this guide:

* [XML (compressed folder)](../examples.xml.zip)
* [JSON (compressed folder)](../examples.json.zip)

#### Consolidated CSV and Excel representations of the profiles

The profile information of the whole guide in a single CSV or Excel file — useful for testers and analysts who want to review element properties across profiles in one table:

* [CSV (compressed folder)](../csvs.zip)
* [Excel (compressed folder)](../excels.zip)

#### Schematrons

* [Schematrons (compressed folder)](../schematrons.zip)

#### ImplementationGuide resource

The `ImplementationGuide` resource carries the technical details of this publication, including its dependencies and publication parameters.

This module publishes that page as [ImplementationGuide-mii-ig-mtb](ImplementationGuide-mii-ig-mtb.md).

#### Version history

Earlier versions and the detailed change history are on the [Versioning](version-history.md) and [Changelog](changes.md) pages.

