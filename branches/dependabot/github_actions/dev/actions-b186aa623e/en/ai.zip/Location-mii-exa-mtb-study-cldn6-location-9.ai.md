# NCT04503278 L9 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NCT04503278 L9**

## Example Location: NCT04503278 L9

-------

**English**

-------

**name**: He Nederlands Kanker Instituut (The Netherlands Cancer Institute) - Antoni van Leeuwenhoek Ziekenhuis (NKI-AVL)

**address**: Amsterdam 1066 Netherlands 

### Positions

| | | |
| :--- | :--- | :--- |
| - | **Longitude** | **Latitude** |
| * | 4.88969 | 52.37403 |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "mii-exa-mtb-study-cldn6-location-9",
  "name" : "He Nederlands Kanker Instituut (The Netherlands Cancer Institute) - Antoni van Leeuwenhoek Ziekenhuis (NKI-AVL)",
  "address" : {
    "city" : "Amsterdam",
    "postalCode" : "1066",
    "country" : "Netherlands"
  },
  "position" : {
    "longitude" : 4.88969,
    "latitude" : 52.37403
  }
}

```
