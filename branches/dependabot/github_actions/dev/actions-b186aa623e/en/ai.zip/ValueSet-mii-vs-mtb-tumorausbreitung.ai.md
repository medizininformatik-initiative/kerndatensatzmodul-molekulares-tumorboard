# MII VS Tumorausbreitung - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Tumorausbreitung**

## ValueSet: MII VS Tumorausbreitung 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/ValueSet/mii-vs-mtb-tumorausbreitung | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-10-13 | *Computable Name*:MII_VS_MTB_Tumorausbreitung |

 
ValueSet zur Angabe der Tumorausbreitung 

 **References** 

* [MII PR MTB Tumorausbreitung](StructureDefinition-mii-pr-mtb-tumorausbreitung.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unsupported Code System Version)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-mtb-tumorausbreitung",
  "language" : "de-DE",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/ValueSet/mii-vs-mtb-tumorausbreitung",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_VS_MTB_Tumorausbreitung",
  "title" : "MII VS Tumorausbreitung",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-13T00:31:45+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "ValueSet zur Angabe der Tumorausbreitung",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "58899004",
        "display" : "No evidence of tumor"
      },
      {
        "code" : "255127006",
        "display" : "Local tumor spread"
      },
      {
        "code" : "128462008",
        "display" : "Metastases"
      },
      {
        "code" : "261665006",
        "display" : "Unknown"
      }]
    }]
  }
}

```
