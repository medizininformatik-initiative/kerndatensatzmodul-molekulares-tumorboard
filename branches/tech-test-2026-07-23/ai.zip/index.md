# Home - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2026.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/ImplementationGuide/mii-kerndatensatzmodul-molekulares-tumorboard | *Version*:2026.0.1 |
| Active as of 2026-07-23 | *Computable Name*:MII_IG_MTB_DE |

# MII Erweiterungsmodul Molekulares Tumorboard

Willkommen bei der Dokumentation des MII Erweiterungsmoduls Molekulares Tumorboard (MTB).

Dieses Modul definiert FHIR-Profile für die Dokumentation von molekularen Tumorboards in der Medizininformatik-Initiative.

