# PatientKimMusterperson-PrimaryDiagnosis-2 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2026.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientKimMusterperson-PrimaryDiagnosis-2**

## Example Condition: PatientKimMusterperson-PrimaryDiagnosis-2

-------

**English**

-------

Profile: [MII PR Onkologie Diagnose Primärtumor](https://medizininformatik-initiative.github.io/kerndatensatzmodul-onkologie/2027.0.0-ballot.1/StructureDefinition-mii-pr-onko-diagnose-primaertumor.html)

**Condition Asserted Date**: 2021-06-10

**clinicalStatus**: Active

**verificationStatus**: Unconfirmed

**category**: Neoplastic disease

**code**: Bösartige Neubildung: Peritoneum, nicht näher bezeichnet

**bodySite**: Ovar

**subject**: [Kim Musterperson (no stated gender), DoB: 1956-03-14](Patient-PatientKimMusterperson.md)

**recordedDate**: 2021-06-10



## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "PatientKimMusterperson-PrimaryDiagnosis-2",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
    "valueDateTime" : "2021-06-10"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "unconfirmed"
    },
    {
      "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
      "code" : "2"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "55342001",
      "display" : "Neoplastic disease"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
      "version" : "2020",
      "code" : "C48.2",
      "display" : "Bösartige Neubildung: Peritoneum, nicht näher bezeichnet"
    }]
  },
  "bodySite" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
      "code" : "C56.9",
      "display" : "Ovar"
    }]
  }],
  "subject" : {
    "reference" : "Patient/PatientKimMusterperson"
  },
  "recordedDate" : "2021-06-10"
}

```
