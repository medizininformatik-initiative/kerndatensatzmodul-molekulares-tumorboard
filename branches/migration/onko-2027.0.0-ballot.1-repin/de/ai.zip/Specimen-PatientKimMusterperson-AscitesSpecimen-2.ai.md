# PatientKimMusterperson-AscitesSpecimen-2 - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2026.0.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **PatientKimMusterperson-AscitesSpecimen-2**

## Beispiel Specimen: PatientKimMusterperson-AscitesSpecimen-2

-------

**German**

-------

Profile: [MII PR Onkologie Specimen](https://medizininformatik-initiative.github.io/kerndatensatzmodul-onkologie/2027.0.0-ballot.1/StructureDefinition-mii-pr-onko-specimen.html)

**accessionIdentifier**: Z230201/23

**type**: Ascitic fluid specimen (specimen)

**subject**: [Kim Musterperson (no stated gender), DoB: 1956-03-14](Patient-PatientKimMusterperson.md)

### Collections

| | |
| :--- | :--- |
| - | **Collected[x]** |
| * | 2023-02-01 |



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "PatientKimMusterperson-AscitesSpecimen-2",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-specimen"]
  },
  "accessionIdentifier" : {
    "value" : "Z230201/23"
  },
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "309201001",
      "display" : "Ascitic fluid specimen (specimen)"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientKimMusterperson"
  },
  "collection" : {
    "collectedDateTime" : "2023-02-01"
  }
}

```
