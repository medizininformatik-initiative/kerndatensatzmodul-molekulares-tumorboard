# Guidance for Implementers - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2026.0.1

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Guidance for Implementers**

## Guidance for Implementers

Technical guidance for DIC implementers on implementing the profiles of the **Molecular Tumor Board** module (ETL from primary systems, FHIR API, validation).

### Profile Content and Inheritance

The following overview shows the module's profiles, their content and their inheritance relations. The image can be viewed and downloaded [individually](MII_MTB_Overview.svg) (provided as `.svg`).

![](MII_MTB_Overview.svg)

### Profile Relations and References

The following overview shows the references between the resources. The image file can be viewed and downloaded [individually](MII-Kerndatensatz-Molekulares-Tumorboard-Beziehungen-und-Referenzen.svg) (provided as `.svg`).

![](MII-Kerndatensatz-Molekulares-Tumorboard-Beziehungen-und-Referenzen.svg)

### QA and Validation

This section documents the FHIR validation status of the MII module Molecular Tumor Board (MTB).

The module is continuously validated against the FHIR R4 standard and the defined profiles. The validation status is documented here transparently.

#### Known issues of the template build (status 2026-09)

**Which numbers come from which terminology server matters here.** The CI build validates against the **MII terminology server (SU-TermServ)** through the organization's client certificate (the template's proxy mechanism) and currently reports **91 errors**. A build without that certificate — e.g. a local build — falls back to the public HL7 server (tx.fhir.org) and reports **144 errors**: the difference is **one family — tx.fhir.org does not host the German terminology content this module validates against.** The table below describes that public-tx-only family; none of it appears on SU-TermServ.

| | | |
| :--- | :--- | :--- |
| ATC codes (`L01XA02`carboplatin,`L01DB01`doxorubicin) "not in ValueSet`mii-vs-medikation-atc`" | 24 | the Medikation module's ValueSet includes BfArM ATC**per yearly version**(2020–2026); tx.fhir.org hosts no BfArM ATC at all ("Invalid criteria version"), so the expansion fails and every membership check errors |
| `Condition/PatientKimMusterperson-PrimaryDiagnosis-2`: "no matching profile" +`reasonReference:Primaertumor`"matching slice not found" +`C56.9`not in the ICD-O-3 topography ValueSet | 30 (4+10+16) | **one cascade**: tx.fhir.org cannot expand ICD-O-3, so the diagnosis's`bodySite`(`C56.9`) cannot be validated → the instance fails its profile check → the therapy recommendations'`resolve()`-based`Primaertumor`slice discriminator cannot match. The instance and the slices are correctly authored |
| SNOMED CT edition`…/900000000000207008/version/20250701`"definition not found" | 12 | the expansion manifest (`input/resources/Parameters-expansion-manifest.json`) pins the international edition 2025-07-01, which tx.fhir.org does not serve |
| LOINC display-name deviations, single Genomics-Reporting ValueSet misses | <10 | display/version drift between the pinned packages and the tx server |
| the nine panel gene-list ValueSets: per-concept`$validate-code`rejected ("must specify either valueSet or url parameter") | up to ~2,486 | SU-TermServ (Ontoserver) rejects the IG Publisher's batch validation of enumerated`ValueSet.compose`concepts from the second concept on — for symbol and HGNC-ID coding alike, while the module's own HGNC instance codings validate fine. Validation for exactly these nine resources is skipped via the IG`no-validate`parameter until the server issue is fixed (reported upstream); the codes themselves are verified HGNC IDs from hgnc_complete_set |

None of these is a defect in the module's profiles or examples; they are terminology-server capability gaps and are tracked here deliberately instead of being suppressed.

#### Terminology server and validation configuration

**MII Terminology Server**: [https://termserv.mii.medizininformatik-initiative.de/fhir](https://termserv.mii.medizininformatik-initiative.de/fhir)

**Validation configuration**: [`advisor.json`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-molekulares-tumorboard/blob/dev/advisor.json)

#### Filtered validation messages

These messages are suppressed via [`advisor.json`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-molekulares-tumorboard/blob/dev/advisor.json):

| | | |
| :--- | :--- | :--- |
| `Terminology_TX_NoValid_16` | ImplementationGuide, StructureDefinition, ValueSet, CodeSystem | External terminology-server limitation: the TX server cannot validate certain codes |
| `UNABLE_TO_INFER_CODESYSTEM` | ImplementationGuide, StructureDefinition, ValueSet, CodeSystem | The validator cannot automatically infer the code system |
| `Structural_VAL_Array_Empty` | ImplementationGuide.definition.page | Empty array in the IG page definition (Simplifier artifact) |
| `MSG_DRAFT` | global | Expected warning for resources in`draft`status during the development phase |
| `dom-6` | DomainResource | FHIR base invariant, known validator artifact |
| `eld-20` | ElementDefinition | ElementDefinition invariant, known validator artifact |
| `LOINC LIST filter` | Observations, Procedures | `There is no declared filter called LIST on code system http://loinc.org`— the CI TX server does not support the LOINC`LIST`filter (see below) |
| SNOMED code`1381317004`not known to the TX server | SNOMED CT | New SNOMED CT code not yet available in the TX-server version |
| `Reference_REF_CantMatchChoice` | global | The validator cannot resolve choice-type references (known limitation) |
| `Validation_VAL_Profile_NoSnapshot` | global | Referenced profile without snapshot (e.g. from dependency packages without snapshots) |

#### Profile-specific issues

| | | | |
| :--- | :--- | :--- | :--- |
| **Genomics Reporting** | Extension | HL7 Genomics Reporting extensions have known validation warnings | 🔵 EXTERNAL |
| **GenomicStudyAnalysis** | Profile mismatch | Bundle validation cannot resolve the profile chain (see below) | 🔵 EXTERNAL |
| **Immunohistochemistry** | Slicing | code.coding slicing with pattern discriminator and value set (see below) | 🔵 EXTERNAL |

#### Profile mismatch in bundle validation

When validating bundles with nested profile references, the FHIR validator may report `PROFILE_MISMATCH` errors although the resources are correctly profiled. This occurs in particular for the `GenomicStudyAnalysis` resource, which is referenced through a profile chain:

**Profile chain:**

* `MII_PR_MTB_NGS_Bericht` → references `MII_PR_MTB_Genomic_Study`
* `MII_PR_MTB_Genomic_Study` → references `MII_PR_MTB_Genomic_Study_Analysis`
* `MII_PR_MTB_Genomic_Study_Analysis` → based on `MII_PR_MolGen_GenomicStudyAnalysis`

**Error message:**

```
PROFILE_MISMATCH: Unable to find a profile match for Procedure/mii-exa-mtb-...-genomic-study-analysis-1

```

**Cause:** The FHIR validator cannot fully resolve this multi-level profile chain in bundle contexts, because the profile references are distributed across several IG packages (MTB → MolGen → HL7 Genomics Reporting).

**Status:** These are validator artifacts, not actual conformance problems. The profiles are correctly defined and the example resources conform.

#### Immunohistochemistry code.coding slicing

The `MII_PR_MTB_Immunohistochemistry` profile uses a slicing on `code.coding` with two slices:

* **spezifisch**: for specific LOINC/SNOMED codes (value-set bound)
* **generisch**: for the generic IHC code `1234806008` (fixed)

**Error message:**

```
Slicing cannot be evaluated: Could not match discriminator ($this) for slice spezifisch

```

**Cause:** The FHIR validator has difficulty evaluating `#pattern` discriminators on `$this` with value-set-bound slices, because the pattern cannot be derived unambiguously from the value set.

**Status:** The profile semantics are correct. The validator cannot fully evaluate the slicing, but the instances conform.

#### Terminology-related issues

| | | |
| :--- | :--- | :--- |
| **HGNC** | Gene symbols not available on all TX servers | 🔵 EXTERNAL |
| **Oncotree** | Tumor classification is external, not validatable via FHIR TX | 🔵 EXTERNAL |
| **LOINC** | Panel codes for genomics partly not validatable;`LIST`filter not supported (see below) | 🔵 EXTERNAL |
| **SNOMED CT** | Newer codes (July 2025+) not available on MII TX servers | 🔵 EXTERNAL |

#### LOINC LIST-filter errors in CI

The CI validation reports 14 errors of the form:

```
Error from http://127.0.0.1:8090/fhir: Error: There is no declared filter called LIST on code system http://loinc.org

```

**Cause:** The `hl7.fhir.uv.genomics-reporting` IG (v3.0.0) uses value sets with LOINC `LIST` filter expressions. The terminology server used in CI does not support this filter. This affects all resources using LOINC codes from Genomics Reporting value sets.

**Affected resources (14):**

| | |
| :--- | :--- |
| Bundle (Kim Musterperson) | GenomicStudyAnalysis, EinfacheVariante (TP53, PIK3R1), CNVariante (CCNE1) |
| Observation (Einfache Variante) | `value`,`method`,`component[0].value` |
| Observation (Copy Number Variant) | `component[0].value` |
| Observation (RNA Fusion) | `value` |
| Procedure (GenomicStudyAnalysis) | `extension.value` |

**Status:** 🔵 EXTERNAL — the error lies in the CI TX server, not in the profiles or examples. The message is filtered via `advisor.json`.

#### Non-validatable SNOMED CT codes

The following SNOMED CT codes are correct, but newer than the version available on the terminology server. They therefore cannot be validated automatically.

##### In-situ hybridization (ISH) methods

| | | |
| :--- | :--- | :--- |
| `1363313004` | In situ hybridization technique (qualifier value) | ISH method (generic) |
| `1303773004` | Fluorescence in situ hybridization technique (qualifier value) | FISH method |
| `787997001` | Chromogenic in situ hybridization (qualifier value) | CISH method |
| `787998006` | Silver in situ hybridization (qualifier value) | SISH method |

##### In-situ hybridization observable entities

| | | |
| :--- | :--- | :--- |
| `1365744007` | Ratio of erb-b2 receptor tyrosine kinase 2 to chromosome 17 centromere signals per cell in malignant neoplasm of breast in excised tissue specimen by in situ hybridization technique (observable entity) | HER2/CEP17 ratio ISH |
| `1365743001` | Human epidermal growth factor receptor 2 gene copy number in malignant neoplasm of breast in excised tissue specimen by in situ hybridization technique (observable entity) | HER2 copy number ISH |
| `1365742006` | Human epidermal growth factor receptor 2/centromeric probe 17 ratio in malignant neoplasm of breast in excised tissue specimen by in situ hybridization technique (observable entity) | HER2/CEP17 ratio (alternative) |

##### Further newer SNOMED CT codes

| | | |
| :--- | :--- | :--- |
| `1234806008` | Observation using immunohistochemistry (observable entity) | IHC observation (generic) |
| `12645001` | Gene amplification (finding) | ISH interpretation |

#### External dependencies

| | | |
| :--- | :--- | :--- |
| `de.medizininformatikinitiative.kerndatensatz.meta` | 2026.0.0 | MII Core Dataset Meta |
| `de.medizininformatikinitiative.kerndatensatz.base` | 2026.0.0 | MII Core Dataset Base |
| `de.medizininformatikinitiative.kerndatensatz.onkologie` | 2026.0.3 | MII Oncology module |
| `de.medizininformatikinitiative.kerndatensatz.molgen` | 2026.0.4 | MII Molecular Genetics module |
| `de.medizininformatikinitiative.kerndatensatz.patho` | 2026.0.0 | MII Pathology module |
| `de.medizininformatikinitiative.kerndatensatz.consent` | 2026.0.0 | MII Consent module |
| `hl7.fhir.uv.genomics-reporting` | 3.0.0 | HL7 Genomics Reporting IG |

#### Status legend

| | | |
| :--- | :--- | :--- |
| 🔴 | **TODO** | Errors to be actively fixed |
| 🟡 | **MONITOR** | Watch, action may be required |
| 🔵 | **EXTERNAL** | External problem, outside our control |
| ⚪ | **FILTERED** | Filtered via advisor.json |

#### Continuous integration

The FHIR validation runs automatically on every push via GitHub Actions:

* **JAVA_FHIR_VALIDATION**: HL7 FHIR Validator (official)
* **DOTNET_FHIR_VALIDATION**: Firely .NET validator (alternative)

🔗 [Show current CI runs](https://github.com/medizininformatik-initiative/kerndatensatzmodul-molekulares-tumorboard/actions)

The validation results, including detailed output, are available as artifacts in the workflow runs.

#### How can I help?

If you would like to contribute to improving validation:

1. **Check**the issues in the GitHub repository
1. **Look**for a`TODO`-marked error that interests you
1. **Create**an issue or pull request in the[GitHub repository](https://github.com/medizininformatik-initiative/kerndatensatzmodul-molekulares-tumorboard)
1. **Discuss**complex validation questions in the MII community

**Note**: this section is maintained manually. For the most current technical state see the CI runs in the repository.

