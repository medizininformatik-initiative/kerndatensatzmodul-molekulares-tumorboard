# Beispiel HRD-Score - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2026.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel HRD-Score**

## Example Observation: Beispiel HRD-Score

-------

**English**

-------

Profile: [MII PR MTB HRD Score](StructureDefinition-mii-pr-mtb-hrd-score.md) version: 2026.0.1

**status**: Final

**category**: Laboratory, Genetics, A characterization of a given biomarker observation.

**code**: Homologous recombination deficiency status analysis [Presence] in Tissue by Molecular genetics method

**subject**: [Maxim Muster (no stated gender), DoB Unknown](Patient-mii-exa-mtb-patient.md)

**value**: 43

**interpretation**: High

**specimen**: [Specimen: status = available; type = Tissue specimen](Specimen-mii-exa-mtb-specimen.md)

> **component****code**: Loss of Heterozygosity**value**: 14

> **component****code**: Telomeric Allelic Imbalance Region**value**: 12

> **component****code**: Large-Scale State Transition**value**: 17



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "MII-EXA-MTB-HRD-Score-1",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-hrd-score|2026.0.1"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory",
      "display" : "Laboratory"
    }]
  },
  {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
      "code" : "GE"
    }]
  },
  {
    "coding" : [{
      "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
      "code" : "biomarker-category"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "107286-7",
      "display" : "Homologous recombination deficiency status analysis [Presence] in Tissue by Molecular genetics method"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-mtb-patient"
  },
  "valueInteger" : 43,
  "interpretation" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
      "code" : "H",
      "display" : "High"
    }]
  }],
  "specimen" : {
    "reference" : "Specimen/mii-exa-mtb-specimen"
  },
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
        "code" : "C18016",
        "display" : "Loss of Heterozygosity"
      }]
    },
    "valueInteger" : 14
  },
  {
    "code" : {
      "coding" : [{
        "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
        "code" : "C129774",
        "display" : "Telomeric Allelic Imbalance Region"
      }]
    },
    "valueInteger" : 12
  },
  {
    "code" : {
      "coding" : [{
        "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
        "code" : "C120466",
        "display" : "Large-Scale State Transition"
      }]
    },
    "valueInteger" : 17
  }]
}

```
