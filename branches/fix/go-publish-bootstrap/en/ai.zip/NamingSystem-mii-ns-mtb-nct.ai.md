# MII NS MTB NCT - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII NS MTB NCT**

## NamingSystem: MII NS MTB NCT 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/NamingSystem/mii-ns-mtb-nct | *Version*:2027.0.0-ballot.1 |
| Active as of 2024-07-19 | *Computable Name*:MII_NS_MTB_NCT |

 
NamingSystem für Identifikatoren des Nationalen Centrums für Tumorerkrankungen (NCT) 



## Resource Content

```json
{
  "resourceType" : "NamingSystem",
  "id" : "mii-ns-mtb-nct",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.url",
    "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/NamingSystem/mii-ns-mtb-nct"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.version",
    "valueString" : "2027.0.0-ballot.1"
  }],
  "name" : "MII_NS_MTB_NCT",
  "status" : "active",
  "kind" : "identifier",
  "date" : "2024-07-19",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "NamingSystem für Identifikatoren des Nationalen Centrums für Tumorerkrankungen (NCT)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "uniqueId" : [{
    "type" : "uri",
    "value" : "https://www.medizininformatik-initiative.de/fhir/modul-mtb/sid/nct",
    "preferred" : true
  }]
}

```
