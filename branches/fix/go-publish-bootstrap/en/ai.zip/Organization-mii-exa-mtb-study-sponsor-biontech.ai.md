# BioNTech Cell & Gene Therapies GmbH - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****BioNTech Cell & Gene Therapies GmbH/b>

## Example Organization: BioNTech Cell & Gene Therapies GmbH

-------

**English**

-------

**type**: Clinical Research Sponsor

**name**: BioNTech Cell & Gene Therapies GmbH



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "mii-exa-mtb-study-sponsor-biontech",
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "crs",
      "display" : "Clinical Research Sponsor"
    }]
  }],
  "name" : "BioNTech Cell & Gene Therapies GmbH"
}

```
