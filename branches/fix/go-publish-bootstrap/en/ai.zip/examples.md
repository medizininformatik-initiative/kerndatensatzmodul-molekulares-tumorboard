# Examples - MII IG Kerndatensatz-Modul Molekulares Tumorboard v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* **Examples**

## Examples

This page lists the example instances of the **Molecular Tumor Board** module. The template ships the synthetic example [Maxim Muster](Patient-mii-exa-mtb-patient.md).

**Synthetic data only** — never use real or realistic-looking patient data in examples.

The module ships **120+ example instances** demonstrating typical MTB scenarios, including the coherent test case **Kim Musterperson** described under [Application Scenarios](anwendungsszenarien.md). The complete, automatically generated list is on the [artifacts summary](artifacts.md).

